# MK163 — Kaira Cardsmith Primary Curriculum · Locked Course Map

Status: AUTHOR-LOCKED five-semester course allocation; detailed daily timetable approved only for Semester I. This is Kaira, not the unnamed Helkir friend.

| Semester | Courses | Count |
|---|---|---|
| I | Genesis Field Theory I; Topology I; Cardsmithing Fundamentals I | 3 |
| II | Genesis Field Theory II; Chemistry I; Introduction to Sigil Architecture; Cardsmithing Fundamentals II | 4 |
| III | Genesis Field Theory III; Quantum Field Theory I; Transduction Theory I | 3 |
| IV | Differential Geometry I; Transduction Theory II; Binding Circle Fundamentals | 3 |
| V | Applied Transduction Systems; Cardsmithing Architecture I; Cardsmithing Laboratory II | 3 |

Total: 16 courses. Semester II's fourth course may be delivered as a lighter practical workshop; **delivery format remains open**.

Biological Sciences and healing-oriented Genesis cards deferred to advanced specialization. Cardsmithing Capstone Studio and standalone Card Safety, Testing and Quality Assurance course removed. Practical safety integrated into instruction. The title Cardsmithing Laboratory II is preserved as approved, although whether its numeral references a separate pre-existing course sequence is open.

### Shared-course cross-reference with Helkir
- Semester I: Genesis Field Theory I (Ailar 11:00–13:00), Topology I (Aiveth 11:00–13:00) — same sections, locked.
- Semester II: Genesis Field Theory II (Helkir Ailar 11:00–13:00) — **proposed same section for Kaira**, not yet day-schedule approved.
- Other course titles may overlap in different semesters, which does not imply shared class attendance.
