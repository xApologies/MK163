# MK163 — Blackstone Keep · Kaira Cardsmith Primary Track · Semester V

**Status: AUTHOR-LOCKED — all six days approved in conversation, 2026-11-12.**

## Protected continuity

- Kaira (not voice-to-text Kira); Helkir is her unnamed healer friend.
- 31-hour day, six weekdays Ailar, Aiden, Aiveth, Ailor, Aithen, Aiven; 96-day semester; weekly timetable repeats.
- Semester V courses: Applied Transduction Systems, Cardsmithing Architecture I, Cardsmithing Laboratory II.
- Helkir Semester V courses: Quantum Field Theory I (Ailar 17:00–19:00), Organic Chemistry I (Aiveth 13:00–15:00), Biology Lab III (Aithen 18:00–20:00). None of the Semester V lectures are identical shared courses.
- Shared study means co-located voluntary study of different subjects, not the same lecture section.
- The practical cardsmithing track builds on Genesis Field Theory, sigil architecture, transduction, binding circles and card construction. Introductory binding circles employ activated sigils, Genesis crystals, vaen, Genesis dust; advanced sigil-independent fabrication is not presumed.
- Nyx, Black Sprite (they/them), Chainmail Robe business; Helkir friend and Princess remain unnamed.
- 25:00 meal slots are personal meal times, not fixed campus cafeteria hours. Aiven is a protected rest day, exactly aligned with Helkir.

## Approved daily schedules

### Day 1 — Ailar

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat and prepare |
| 11:00–13:00 | Shared independent study | Kaira: Applied Transduction preparation; Helkir: Quantum Field Theory I preparation |
| 13:00–15:00 | Applied Transduction Systems — REQUIRED | Genesis Field Studies Department; Helkir works on mathematical exercises |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–17:00 | Independent study | Kaira: transduction review; Helkir: field-theory exercises |
| 17:00–19:00 | Cardsmithing research / business | Optional card development or Chainmail Robe; Helkir attends Quantum Field Theory I |
| 19:00–20:00 | Shared study / tutoring | Both available for coursework review |
| 20:00–21:00 | Dinner together | Shared meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, campus recreation |
| 25:00–26:00 | Late meal | Personal dining; not a cafeteria opening time |
| 26:00–31:00 | Personal time | Reading, hobbies, recreation or rest |

### Day 2 — Aiden

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat and prepare |
| 11:00–13:00 | Shared independent study | Kaira: Applied Transduction review; Helkir: Quantum Field Theory I review |
| 13:00–15:00 | Independent research — together | Kaira: card architecture and configurations; Helkir: quantum theory assignments |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Shared study / course preparation | Kaira: Cardsmithing Architecture I; Helkir: Organic Chemistry I |
| 18:00–20:00 | Open campus time | Friends, Nyx, Black Sprite or Chainmail Robe |
| 20:00–21:00 | Dinner together | Shared meal |
| 21:00–25:00 | Free time | Campus events, recreation and friendship |
| 25:00–26:00 | Late meal | Personal dining; not a cafeteria opening time |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation or socializing |

### Day 3 — Aiveth

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat and prepare |
| 11:00–13:00 | Shared independent study | Kaira: Cardsmithing Architecture I preparation; Helkir: Organic Chemistry I preparation |
| 13:00–15:00 | Independent architecture study | Kaira: card configurations; Helkir attends Organic Chemistry I |
| 15:00–16:00 | Lunch together | Both available |
| 16:00–17:00 | Lecture preparation | Architecture notes and travel to Genesis Field Studies |
| 17:00–19:00 | Cardsmithing Architecture I — REQUIRED | Genesis Field Studies Department; Helkir chemistry exercises / Archives |
| 19:00–20:00 | Shared study / lecture review | Both available after Kaira lecture |
| 20:00–21:00 | Dinner together | Shared meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite and campus recreation |
| 25:00–26:00 | Late meal | Personal dining; not a cafeteria opening time |
| 26:00–31:00 | Personal time | Reading, hobbies, socializing or rest |

### Day 4 — Ailor

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat and prepare |
| 11:00–13:00 | Shared independent study | Kaira: Cardsmithing Laboratory II preparation; Helkir: Biology Lab III preparation |
| 13:00–15:00 | Shared practical study | Kaira: card construction and configuration exercises; Helkir: advanced biological exercises |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Shared study / tutoring | Kaira: Applied Transduction Systems and Cardsmithing Architecture I; Helkir: Quantum Field Theory I and Organic Chemistry I |
| 18:00–20:00 | Open campus time | Friends, Nyx, Black Sprite or Chainmail Robe |
| 20:00–21:00 | Dinner together | Shared meal |
| 21:00–25:00 | Free time | Campus events, recreation and friendship |
| 25:00–26:00 | Late meal | Personal dining; not a cafeteria opening time |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation or socializing |

### Day 5 — Aithen

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Prepare for morning laboratory |
| 11:00–13:00 | Cardsmithing Laboratory II — REQUIRED | Genesis Field Studies Department; Helkir prepares for Biology Lab III |
| 13:00–15:00 | Shared independent study | Kaira: laboratory results and card configurations; Helkir: Biology Lab III preparation |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Shared practical study | Kaira: Genesis card construction review; Helkir: biological laboratory preparation |
| 18:00–20:00 | Optional Cardsmithing practice / business | Kaira: card designs, Chainmail Robe or personal time; Helkir attends Biology Lab III |
| 20:00–21:00 | Dinner together | Both available after 20:00 |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite and campus recreation |
| 25:00–26:00 | Late meal | Personal dining time |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation or socializing |

### Day 6 — Aiven

| Local time | Activity | Notes |
|---|---|---|
| 00:00–12:00 | Sleep | 12 hours; rest-day sleep-in |
| 12:00–13:00 | Breakfast | Relaxed start; no academic obligations |
| 13:00–18:00 | Open campus exploration | Blackstone grounds, Grand Archives, shopping, city excursions, Helkir friend |
| 18:00–19:00 | Lunch together | Same break as Helkir |
| 19:00–23:00 | Recreation and social activities | Campus events, games, hobbies and friends |
| 23:00–25:00 | Personal downtime | Relaxation, reading for pleasure, Nyx, Black Sprite |
| 25:00–26:00 | Dinner | Personal dining; not fixed cafeteria hours |
| 26:00–31:00 | Unstructured personal time | Friendship, hobbies, rest or preparation for next cycle |

## Semester V course and schedule audit

| Day | Required class | Time |
|---|---|---|
| Ailar | Applied Transduction Systems | 13:00–15:00 |
| Aiveth | Cardsmithing Architecture I | 17:00–19:00 |
| Aithen | Cardsmithing Laboratory II | 11:00–13:00 |

- Aiden and Ailor: 0 hours required lecture, 6 hours optional shared study, 11 hours open personal time.
- Ailar, Aiveth and Aithen: 2 hours required class, 6 hours optional study or business, 9 hours open personal time. On Aiveth, the 6 hours include 11:00–13:00, 13:00–15:00, 16:00–17:00, 19:00–20:00.
- Aiven: 0 required class, 0 required study, 16 hours open personal time; 12 hours sleep.
- Semester V completes Kaira's five-semester primary track: 16 courses, 30 recurring daily schedules total across Semesters I–V. This does not assert an advanced/master's qualification.
- The author approved Day 6 by declaring all five semesters complete and requesting the cumulative ZIP.
