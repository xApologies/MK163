# MK163 — Blackstone Keep · Kaira Cardsmith Primary Track · Semester III

**Status: AUTHOR-LOCKED — all six days approved in conversation, 2026-11-12.**

## Protected continuity

- Kaira (not voice-to-text Kira); Helkir (unnamed healer friend).
- 31-hour day; six weekdays Ailar, Aiden, Aiveth, Ailor, Aithen, Aiven; 96-day semester.
- Semester III: Genesis Field Theory III, Quantum Field Theory I, Transduction Theory I.
- Shared Genesis Field Theory III with Helkir on Ailar 13:00–15:00.
- Other lectures: Aiveth Quantum Field Theory I 11:00–13:00; Aithen Transduction Theory I 18:00–20:00.
- Study together whenever schedules permit, including when studying different subjects. These are voluntary academic blocks, not additional compulsory classes.
- Aiven is a rest day exactly aligned with Helkir; meals at 25:00 are personal times, not institutional opening times.
- Preserve story continuity: Nyx, Black Sprite (they/them), Chainmail Robe business. Helkir friend remains unnamed.

## Approved daily schedules

### Day 1 — Ailar

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, prepare |
| 11:00–13:00 | Shared independent study | Both review Genesis Field Theory II and prepare |
| 13:00–15:00 | Genesis Field Theory III — REQUIRED | Same lecture section as Helkir friend |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Shared field-theory exercises | Optional advanced Genesis review together |
| 18:00–20:00 | Shared independent research | Kaira transduction/quantum; Helkir field theory |
| 20:00–21:00 | Dinner together | Evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, campus activities |
| 25:00–26:00 | Late meal | Personal dining time; not cafeteria opening |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation or rest |


### Day 2 — Aiden

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, prepare |
| 11:00–13:00 | Shared Genesis Field Theory III review | Same course, reviewing Day 1 |
| 13:00–15:00 | Independent research — together | Kaira quantum theory/transduction; Helkir Genesis Field research |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Independent study — together | Kaira Quantum Field Theory I; Helkir Differential Geometry II |
| 18:00–20:00 | Open campus time | Friends, Nyx, Black Sprite or Chainmail Robe business |
| 20:00–21:00 | Dinner together | Evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, campus activities |
| 25:00–26:00 | Late meal | Personal dining time; not cafeteria opening |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation or rest |


### Day 3 — Aiveth

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, prepare |
| 11:00–13:00 | Quantum Field Theory I — REQUIRED | Quantum Field Studies; Helkir studies geometry |
| 13:00–15:00 | Shared independent study | Kaira quantum review; Helkir geometry exercises |
| 15:00–16:00 | Lunch together | Both available |
| 16:00–17:00 | Independent study | Kaira reviews notes; Helkir lecture preparation |
| 17:00–19:00 | Quantum exercises / personal projects | Optional; Helkir Differential Geometry II lecture |
| 19:00–20:00 | Shared study / lecture review | Both available; Helkir independent review |
| 20:00–21:00 | Dinner together | Evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, campus activities |
| 25:00–26:00 | Late meal | Personal dining time; not cafeteria opening |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation or rest |


### Day 4 — Ailor

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, prepare |
| 11:00–13:00 | Shared independent study | Kaira Transduction Theory I preparation; Helkir Chemistry I preparation |
| 13:00–15:00 | Shared practical study | Kaira transduction configurations; Helkir chemistry exercises |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Shared study / tutoring | Kaira quantum review; Helkir Genesis Field III / Geometry II |
| 18:00–20:00 | Open campus time | Friends, Nyx, Black Sprite or business |
| 20:00–21:00 | Dinner together | Evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, campus activities |
| 25:00–26:00 | Late meal | Personal dining time; not cafeteria opening |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation or rest |


### Day 5 — Aithen

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, prepare |
| 11:00–13:00 | Independent study | Kaira transduction preparation; Helkir Chemistry I lecture |
| 13:00–15:00 | Shared study session | Kaira transduction configurations; Helkir chemistry exercises |
| 15:00–16:00 | Lunch together | Both available |
| 16:00–18:00 | Shared study / research | Kaira Genesis/transduction; Helkir chemistry consultation/Archives |
| 18:00–20:00 | Transduction Theory I — REQUIRED | Evening lecture, Genesis Field Studies; Helkir personal study |
| 20:00–21:00 | Dinner together | Evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, campus activities |
| 25:00–26:00 | Late meal | Personal dining time; not cafeteria opening |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation or rest |


### Day 6 — Aiven

| Local time | Activity | Notes |
|---|---|---|
| 00:00–12:00 | Sleep | 12 hours; rest-day sleep-in |
| 12:00–13:00 | Breakfast | Relaxed start; no academic obligations |
| 13:00–18:00 | Open campus exploration | Blackstone grounds, Grand Archives, shopping, city excursions, Helkir friend |
| 18:00–19:00 | Lunch together | Same break as Helkir friend |
| 19:00–23:00 | Recreation and social activities | Events, games, hobbies, friendship |
| 23:00–25:00 | Personal downtime | Pleasure reading, relaxation, Nyx, Black Sprite |
| 25:00–26:00 | Dinner | Personal meal; cafeteria hours flexible |
| 26:00–31:00 | Unstructured personal time | Friends, hobbies, Nyx, Black Sprite, rest |

