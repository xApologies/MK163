# MK163 — Blackstone Keep · Kaira Cardsmith Primary Track · Semester I

**Status: AUTHOR-LOCKED — six days approved in conversation, 2026-11-12.**

## Canonical constraints

- Protected character spelling: **Kaira** (voice-to-text may substitute Kira).
- **Helkir** is the protected spelling for the unnamed healer friend.
- Local day: 31 hours. Six-day cycle: Ailar, Aiden, Aiveth, Ailor, Aithen, Aiven.
- Semester: 96 local days = sixteen six-day cycles. Institutional event calendar is separate.
- Required lectures: Day 1 Genesis Field Theory I 11:00–13:00; Day 3 Topology I 11:00–13:00; Day 5 Cardsmithing Fundamentals I 16:00–18:00.
- Day 1 and Day 3 lectures are the **same sections** as the unnamed Helkir friend. Day 5 Helkir Anatomy I is 18:00–20:00.
- Days 2 and 4: optional independent study; Day 6: rest without compulsory coursework.
- Meal times are personal schedule slots, not fixed campus cafeteria opening hours.
- Study blocks are optional; friendship and social interactions are opportunities rather than scripted outcomes.

## Approved six-day timetable

### Day 1 — Ailar · Genesis Field Theory I

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | First day at Blackstone |
| 11:00–13:00 | Genesis Field Theory I | Required shared lecture with unnamed Helkir friend |
| 13:00–15:00 | Shared study session | Optional Genesis Field Theory review; proposed beginning of study partnership |
| 15:00–16:00 | Lunch | Opportunity to get acquainted |
| 16:00–18:00 | Cardsmithing preparation | Optional introductory reading and research |
| 18:00–20:00 | Independent study / business | Optional coursework or Chainmail Robe business |
| 20:00–21:00 | Dinner | Personal meal |
| 21:00–25:00 | Free time | Nyx, Black Sprite, friends, campus life |
| 25:00–26:00 | Late meal | Personal dining time |
| 26:00–31:00 | Personal time | Rest, reading, hobbies or socializing |

**Approval:** Author approved this day in sequence.

### Day 2 — Aiden · Independent study

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake and prepare |
| 11:00–13:00 | Shared Genesis Field Theory review | Optional study with Helkir friend |
| 13:00–15:00 | Cardsmithing Fundamentals study | Optional card configurations and workshop preparation |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Topology I preparation | Optional exercises for shared Day 3 lecture |
| 18:00–20:00 | Open campus time | Nyx, Black Sprite, friends or Chainmail Robe business |
| 20:00–21:00 | Dinner | Personal meal |
| 21:00–25:00 | Free time | Friends, recreation, campus activities |
| 25:00–26:00 | Late meal | Personal dining time |
| 26:00–31:00 | Personal time | Reading, relaxation, hobbies or rest |

**Approval:** Author approved this day in sequence.

### Day 3 — Aiveth · Topology I

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Prepare for Mathematics Department |
| 11:00–13:00 | Topology I | Required shared lecture with Helkir friend |
| 13:00–15:00 | Shared topology exercises | Optional mathematical practice together |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Mathematics tutoring / Archives | Optional consultation or reading |
| 18:00–20:00 | Cardsmithing and topology study | Optional connection between geometry and card configurations |
| 20:00–21:00 | Dinner | Personal meal |
| 21:00–25:00 | Free time | Nyx, Black Sprite, friends, campus activities |
| 25:00–26:00 | Late meal | Personal dining time |
| 26:00–31:00 | Open personal time | Reading, hobbies, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 4 — Ailor · Independent study / Cardsmithing

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake and prepare |
| 11:00–13:00 | Cardsmithing Fundamentals I preparation | Optional card principles, sigils, coursework |
| 13:00–15:00 | Independent Cardsmithing practice | Optional design, configurations or workshop |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Shared study / tutoring | Optional Genesis Field Theory and Topology review with Helkir friend |
| 18:00–20:00 | Business and personal projects | Chainmail Robe work, card orders or interests |
| 20:00–21:00 | Dinner | Personal meal |
| 21:00–25:00 | Free time | Nyx, Black Sprite, friends, campus activities |
| 25:00–26:00 | Late meal | Personal dining time |
| 26:00–31:00 | Personal time | Reading, recreation, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 5 — Aithen · Cardsmithing Fundamentals I

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake and prepare |
| 11:00–13:00 | Independent Cardsmithing study | Optional preparation |
| 13:00–15:00 | Card construction exercises | Optional practical exercises |
| 15:00–16:00 | Lunch and travel | Prepare for class |
| 16:00–18:00 | Cardsmithing Fundamentals I | Required lecture · 2 hours |
| 18:00–20:00 | Optional review / workshop / business | Helkir friend attends Anatomy I during this period |
| 20:00–21:00 | Dinner | Both friends free after 20:00 |
| 21:00–25:00 | Free time | Nyx, Black Sprite, friends |
| 25:00–26:00 | Late meal | Personal dining time |
| 26:00–31:00 | Personal time | Recreation or rest |

**Approval:** Author approved this day in sequence.

### Day 6 — Aiven · Rest and recreation

| Local time | Activity | Details |
|---|---|---|
| 00:00–12:00 | Sleep | 12 hours · rest-day sleep-in |
| 12:00–13:00 | Breakfast | Relaxed morning |
| 13:00–18:00 | Open campus exploration | Blackstone, shopping, Archives, city or Helkir friend |
| 18:00–19:00 | Lunch | Meal with friends |
| 19:00–23:00 | Recreation and social activities | Events, games, hobbies, Helkir friend |
| 23:00–25:00 | Personal downtime | Reading, Nyx, Black Sprite or relaxation |
| 25:00–26:00 | Dinner | Personal dining; cafeteria hours not fixed |
| 26:00–31:00 | Unstructured personal time | Friends, hobbies, Nyx, Black Sprite or rest |

**Approval:** Author approved this day in sequence.

## Narrative and coordination notes

- During the shared Day 1 Genesis Field Theory I class, Kaira meets the unnamed Helkir student and they hit it off as study partners. Exact scene dialogue is not locked.
- They also share Day 3 Topology I; independent study and Aiven rest-day windows align.
- Kaira has an existing Chainmail Robe business and responsibilities to Nyx and the Black Sprite (they/them).
- The princess is not yet scheduled; no princess class overlap has been established.
