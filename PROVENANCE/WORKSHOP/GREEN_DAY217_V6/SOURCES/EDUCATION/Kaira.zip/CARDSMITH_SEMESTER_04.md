# MK163 — Blackstone Keep · Kaira Cardsmith Primary Track · Semester IV

**Status: AUTHOR-LOCKED — all six days approved in conversation, 2026-11-12.**

## Protected continuity

- Kaira (not voice-to-text Kira); Helkir (unnamed healer friend).
- 31-hour day; weekdays Ailar, Aiden, Aiveth, Ailor, Aithen, Aiven; 96-day semester.
- Semester IV courses: Differential Geometry I, Transduction Theory II, Binding Circle Fundamentals.
- Helkir Semester IV courses: Differential Geometry III, Chemistry II, Biology Lab II. These are different courses, not shared lectures.
- Voluntary shared study whenever schedules permit, including when working on different subjects.
- Binding Circle Fundamentals is introductory: activated sigil and binding circle organize card construction using Genesis crystals, vaen, and Genesis dust. Advanced sigil-independent card architecture is outside this course; exact fabrication protocol is not established.
- Aiven is a rest day aligned with Helkir. Meals at 25:00 are personal times, not cafeteria opening times.
- Preserve Nyx, Black Sprite (they/them), Chainmail Robe business. Helkir friend remains unnamed.

## Approved daily schedules

### Day 1 — Ailar

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat and prepare |
| 11:00–13:00 | Shared mathematics study | Kaira: Differential Geometry I preparation; Helkir: Differential Geometry III review |
| 13:00–15:00 | Shared geometry exercises | Both study mathematics at their own levels |
| 15:00–17:00 | Differential Geometry I — REQUIRED | Mathematics Department; Helkir attends Differential Geometry III in a different class |
| 17:00–18:00 | Lunch together | Both lectures end at 17:00 |
| 18:00–20:00 | Shared mathematics review | Optional geometry practice, tutoring, Grand Archives |
| 20:00–21:00 | Dinner together | Shared evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, campus activities |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours not fixed |
| 26:00–31:00 | Personal time | Reading, hobbies, recreation or rest |

### Day 2 — Aiden

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat and prepare |
| 11:00–13:00 | Shared mathematics review | Kaira: Differential Geometry I; Helkir: Differential Geometry III |
| 13:00–15:00 | Independent research — together | Kaira: transduction systems; Helkir: mathematics research |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Independent study — together | Kaira: Transduction Theory II preparation; Helkir: Chemistry II preparation |
| 18:00–20:00 | Open campus time | Friends, Nyx, Black Sprite, Chainmail Robe business |
| 20:00–21:00 | Dinner together | Shared evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, campus activities |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours not fixed |
| 26:00–31:00 | Personal time | Reading, hobbies, recreation or rest |

### Day 3 — Aiveth

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat and prepare |
| 11:00–13:00 | Independent transduction study | Kaira prepares; Helkir attends Chemistry II lecture |
| 13:00–15:00 | Shared study session | Kaira: Transduction Theory II; Helkir: chemistry exercises |
| 15:00–16:00 | Lunch together | Both available |
| 16:00–18:00 | Transduction Theory II — REQUIRED | Genesis Field Studies Department; Helkir works on chemistry research/tutoring |
| 18:00–20:00 | Shared study / tutoring | Kaira: transduction review; Helkir: chemistry review / Archives |
| 20:00–21:00 | Dinner together | Shared evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, campus activities |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours not fixed |
| 26:00–31:00 | Personal time | Reading, hobbies, recreation or rest |

### Day 4 — Ailor

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat and prepare |
| 11:00–13:00 | Shared independent study | Kaira: Binding Circle Fundamentals preparation; Helkir: Biology Lab II preparation |
| 13:00–15:00 | Shared practical study | Kaira: containment configurations and binding principles; Helkir: biology exercises |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Shared study / tutoring | Kaira: Differential Geometry I / Transduction II; Helkir: Differential Geometry III / Chemistry II |
| 18:00–20:00 | Open campus time | Friends, Nyx, Black Sprite, Chainmail Robe business |
| 20:00–21:00 | Dinner together | Shared evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, campus activities |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours not fixed |
| 26:00–31:00 | Personal time | Reading, hobbies, recreation or rest |

### Day 5 — Aithen

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat and prepare |
| 11:00–13:00 | Shared independent study | Kaira: Binding Circle preparation; Helkir: Biology Lab II preparation |
| 13:00–15:00 | Binding Circle Fundamentals — REQUIRED | Binding Circle Department; introductory sigil-activated Genesis card construction |
| 15:00–16:00 | Lunch together | Both available |
| 16:00–18:00 | Shared study / practical review | Kaira: binding configurations; Helkir: Biology Lab II preparation |
| 18:00–20:00 | Optional Cardsmithing practice | Card construction, business or personal time; Helkir attends Biology Lab II |
| 20:00–21:00 | Dinner together | Shared evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, campus activities |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours not fixed |
| 26:00–31:00 | Personal time | Reading, hobbies, recreation or rest |

### Day 6 — Aiven

| Local time | Activity | Notes |
|---|---|---|
| 00:00–12:00 | Sleep | 12 hours; rest-day sleep-in |
| 12:00–13:00 | Breakfast | Relaxed start; no academic obligations |
| 13:00–18:00 | Open campus exploration | Blackstone, Grand Archives, shopping, city excursions, Helkir friend |
| 18:00–19:00 | Lunch together | Same break as Helkir |
| 19:00–23:00 | Recreation and social activities | University events, games, hobbies, friendship |
| 23:00–25:00 | Personal downtime | Reading for pleasure, relaxation, Nyx, Black Sprite |
| 25:00–26:00 | Dinner | Personal meal; cafeteria hours flexible |
| 26:00–31:00 | Unstructured personal time | Friends, hobbies, Nyx, Black Sprite, rest |

