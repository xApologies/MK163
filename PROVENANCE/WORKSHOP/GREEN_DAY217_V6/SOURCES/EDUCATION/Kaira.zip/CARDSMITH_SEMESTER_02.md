# MK163 — Blackstone Keep · Kaira Cardsmith Primary Track · Semester II

**Status: AUTHOR-LOCKED — all six days approved in conversation, 2026-11-12.**

## Protected continuity

- Kaira (not voice-to-text Kira); Helkir (unnamed healer friend).
- 31-hour local day; six weekdays Ailar, Aiden, Aiveth, Ailor, Aithen, Aiven; 96-day semester.
- Semester II courses: Genesis Field Theory II, Chemistry I, Introduction to Sigil Architecture, Cardsmithing Fundamentals II.
- Shared Genesis Field Theory II lecture with Helkir on Ailar 11:00–13:00.
- Study sessions are coordinated social routines but optional academically; different subjects may be studied side by side.
- Aiven is a fully open rest day, aligned with Helkir.
- 25:00 meal is a personal meal slot, not a campus cafeteria opening time.

## Approved daily schedules

### Day 1 — Ailar

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake and prepare |
| 11:00–13:00 | Genesis Field Theory II — REQUIRED | Same lecture section as Helkir friend |
| 13:00–15:00 | Shared Genesis Field study | Optional exercises with Helkir friend |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Cardsmithing and sigil research | Optional preparation |
| 18:00–20:00 | Independent study / business | Optional coursework or Chainmail Robe business |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, and campus life |
| 25:00–26:00 | Late meal | Personal meal; cafeteria opening times not fixed |
| 26:00–31:00 | Personal time | Reading, hobbies, socializing or rest |

### Day 2 — Aiden

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake and prepare |
| 11:00–13:00 | Shared Genesis Field Theory II review | Both study the same course together |
| 13:00–15:00 | Independent study — together | Kaira Cardsmithing/Chemistry I; Helkir independent research |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Independent study — together | Kaira Chemistry I; Helkir Differential Geometry I |
| 18:00–20:00 | Open campus time | Friends, Nyx, Black Sprite, business |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, and campus life |
| 25:00–26:00 | Late meal | Personal meal; cafeteria opening times not fixed |
| 26:00–31:00 | Personal time | Reading, hobbies, socializing or rest |

### Day 3 — Aiveth

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake and prepare |
| 11:00–13:00 | Chemistry I — REQUIRED | Chemistry Department; Helkir friend studying geometry |
| 13:00–15:00 | Chemistry review / shared study | Helkir friend studies geometry alongside Kaira |
| 15:00–16:00 | Lunch | Helkir friend in Differential Geometry I 15:00–17:00 |
| 16:00–18:00 | Independent study / Cardsmithing | Helkir lecture ends 17:00; then lunch/rest |
| 18:00–20:00 | Shared study / tutoring | Both available for coursework |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, and campus life |
| 25:00–26:00 | Late meal | Personal meal; cafeteria opening times not fixed |
| 26:00–31:00 | Personal time | Reading, hobbies, socializing or rest |

### Day 4 — Ailor

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake and prepare |
| 11:00–13:00 | Shared independent study | Kaira sigil fundamentals; Helkir Biology Lab I preparation |
| 13:00–15:00 | Shared study / practical preparation | Kaira card configurations; Helkir biological exercises |
| 15:00–17:00 | Introduction to Sigil Architecture — REQUIRED | Genesis Field Studies Department |
| 17:00–18:00 | Lunch and rest | Helkir friend has study group until 18:00 |
| 18:00–20:00 | Shared free time | Campus, Grand Archives, friends, business |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, and campus life |
| 25:00–26:00 | Late meal | Personal meal; cafeteria opening times not fixed |
| 26:00–31:00 | Personal time | Reading, hobbies, socializing or rest |

### Day 5 — Aithen

| Local time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake and prepare |
| 11:00–13:00 | Shared independent study | Kaira Cardsmithing Fundamentals II; Helkir Biology Lab I preparation |
| 13:00–15:00 | Shared practical study | Kaira card construction; Helkir biological exercises |
| 15:00–16:00 | Lunch | Shared meal |
| 16:00–18:00 | Cardsmithing Fundamentals II — REQUIRED | Genesis Field Studies Department |
| 18:00–20:00 | Optional Cardsmithing review / business | Helkir friend in Biology Lab I 18:00–20:00 |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, Nyx, Black Sprite, and campus life |
| 25:00–26:00 | Late meal | Personal meal; cafeteria opening times not fixed |
| 26:00–31:00 | Personal time | Reading, hobbies, socializing or rest |

### Day 6 — Aiven

| Local time | Activity | Notes |
|---|---|---|
| 00:00–12:00 | Sleep | 12-hour rest-day sleep-in |
| 12:00–13:00 | Breakfast | No academic obligations |
| 13:00–18:00 | Open campus exploration | Shared time with Helkir friend; campus, city, Archives |
| 18:00–19:00 | Lunch together | Shared rest-day meal |
| 19:00–23:00 | Recreation and social activities | Friends and campus events |
| 23:00–25:00 | Personal downtime | Nyx, Black Sprite, reading or rest |
| 25:00–26:00 | Dinner | Flexible cafeteria hours |
| 26:00–31:00 | Unstructured personal time | Friends, rest, hobbies |

## Friendship and conflict audit

- Day 1: 11:00–13:00 shared lecture; 13:00–15:00 shared Genesis Field study.
- Day 2: 11:00–13:00 shared subject; 13:00–15:00 and 16:00–18:00 parallel independent study.
- Day 3: 13:00–15:00 and 18:00–20:00 study together; Helkir Differential Geometry I 15:00–17:00.
- Day 4: 11:00–15:00 parallel study; Kaira sigil lecture 15:00–17:00; Helkir Biology Lab I preparation on this day.
- Day 5: 11:00–15:00 parallel study; Kaira class 16:00–18:00, Helkir lab 18:00–20:00.
- Day 6: fully aligned rest-day timetable.

## Scope
This is a recurring six-day weekly schedule, not a claim that each day is a separate one-off event. Semester-wide Blackstone calendar remains separate.