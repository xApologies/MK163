# MK163 — Helkir Primary Curriculum · Cumulative Checkpoint 05

**Status:** All five semesters are author-approved and locked in the working model.

This archive contains complete six-day recurring schedules for Semesters I–V (30 daily timetables). Each semester is 96 local days, comprising sixteen repetitions of its six-day schedule. The files are not a literal day-by-day 480-day event calendar.

**Protected vocabulary:** Helkir (not healer as the canonical track label), Kaira (protagonist). The Helkir student remains unnamed.

**Academic cycle:** 31-hour local day; Ailar, Aiden, Aiveth, Ailor, Aithen, Aiven; required sessions on Days 1, 3, 5; optional academic work on Days 2, 4; rest on Day 6.

**Scope:** Primary Helkir track only; Kaira's Cardsmith curriculum and the Princess's schedule remain separate and uncreated. The 96-day campus-wide event calendar is independent and is not included here.

**Preservation:** Semester files 01–04 are carried byte-for-byte from cumulative checkpoint 04. Semester 05 records the approved schedule from this conversation. Future edits should create a new checkpoint rather than silently changing locked schedules. Manifest hashes are SHA-256 of the exact archived file bytes.

**Repository status:** Local export only; no GitHub publication is claimed.
