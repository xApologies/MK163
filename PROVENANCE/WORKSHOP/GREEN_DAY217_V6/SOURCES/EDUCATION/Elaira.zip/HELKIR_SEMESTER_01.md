# MK163 — Blackstone Keep · Helkir Primary Track · Semester I

**Status: AUTHOR-LOCKED — six-day weekly cycle (2026-11-12).**

The unnamed future Helkir friend of Kaira follows this schedule. This is NOT Kaira’s Cardsmithing schedule. Canonical spelling is **Helkir** (H-E-L-K-I-R); “healer” is a descriptive gloss, not an alternative in-world name.

## Scope and invariants

- Six-day week: Ailar, Aiden, Aiveth, Ailor, Aithen, Aiven. Local day is 31 hours.
- Required lectures: Day 1 Genesis Field Theory I 11:00–13:00; Day 3 Topology I 11:00–13:00; Day 5 Anatomy I 18:00–20:00. Total 6 formal lecture hours per six-day cycle.
- Days 2 and 4 are non-lecture days with student-directed optional study and practice. Day 6 is a genuine rest/recreation day.
- Optional study blocks are *not* compulsory classes. Actual friendships and activities are not pre-scripted.
- This repeating student timetable is distinct from the university-wide recurring 96-day semester event calendar.
- These day labels are positions in the six-day academic cycle, not fixed calendar dates or the first six absolute days of the semester.
- Source lineage: MK147 `Calendar - Kira.pdf`, `Class Schedule - Kira.pdf`, `MASTER_schedule.pdf`, adapted by author-approved MK163 conversation decisions. Historical MK147 schedule is not active MK163 canon.

## Approved six-day timetable

### Day 1 — Ailar · Genesis Field Theory I

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, travel to department |
| 11:00–13:00 | Genesis Field Theory I | Required formal lecture, 2 hours |
| 13:00–15:00 | Guided exercises | Optional course practice or shared study |
| 15:00–16:00 | Lunch and rest | — |
| 16:00–18:00 | Consultation / independent study | Optional tutorials, questions or Grand Archives |
| 18:00–20:00 | Personal study | Flexible review, homework or research |
| 20:00–21:00 | Dinner | — |
| 21:00–25:00 | Free time | Friends, campus activities, recreation |
| 25:00–26:00 | Evening meal | — |
| 26:00–31:00 | Open personal time | Friends, reading, exploring, resting |

**Approval:** Author approved Day 1 in sequence.

### Day 2 — Aiden · Independent study / practical

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | — |
| 11:00–13:00 | Genesis Field Theory review | Revisit Day 1 lecture, complete exercises; optional |
| 13:00–15:00 | Independent research | Grand Archives, reading or assignments; optional |
| 15:00–16:00 | Lunch | — |
| 16:00–18:00 | Study group / tutoring | Optional collaborative study or faculty assistance |
| 18:00–20:00 | Open campus time | Explore, visit departments, meet friends |
| 20:00–21:00 | Dinner | — |
| 21:00–25:00 | Free time | Friends, university events, hobbies |
| 25:00–26:00 | Evening meal | — |
| 26:00–31:00 | Personal time | Reading, recreation, social activities |

**Approval:** Author approved Day 2 in sequence.

### Day 3 — Aiveth · Topology I

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Travel to Mathematics Department |
| 11:00–13:00 | Topology I | Required formal lecture, 2 hours |
| 13:00–15:00 | Guided topology exercises | Optional mathematical practice |
| 15:00–16:00 | Lunch | — |
| 16:00–18:00 | Mathematics tutoring / Archives | Optional faculty consultation or independent reading |
| 18:00–20:00 | Topology review | Homework, conceptual exercises, preparation; flexible |
| 20:00–21:00 | Dinner | — |
| 21:00–25:00 | Free time | Friends, campus events, social activities |
| 25:00–26:00 | Evening meal | — |
| 26:00–31:00 | Open personal time | Reading, hobbies, rest or socializing |

**Approval:** Author approved Day 3 in sequence.

### Day 4 — Ailor · Independent study / practical

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | — |
| 11:00–13:00 | Anatomy preparation | Review ahead of Day 5; optional |
| 13:00–15:00 | Independent practical study | Optional biological demonstrations, supervised observation or exercises |
| 15:00–16:00 | Lunch | — |
| 16:00–18:00 | Study group / tutoring | Optional Genesis Field Theory and Topology review |
| 18:00–20:00 | Open campus time | Departments, Archives, friends |
| 20:00–21:00 | Dinner | — |
| 21:00–25:00 | Free time | Friends, campus events, hobbies and recreation |
| 25:00–26:00 | Evening meal | — |
| 26:00–31:00 | Personal time | Reading, social activities, independent projects or rest |

**Approval:** Author approved Day 4 in sequence.

### Day 5 — Aithen · Anatomy I

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | — |
| 11:00–13:00 | Personal study | Anatomy preparation or independent coursework; swapped with lecture |
| 13:00–15:00 | Guided exercises | Optional anatomy preparation and practical study |
| 15:00–16:00 | Lunch | — |
| 16:00–18:00 | Tutoring / Archives | Optional research or faculty consultation |
| 18:00–20:00 | Anatomy I | Required formal lecture, 2 hours; evening slot explicitly author-selected |
| 20:00–21:00 | Dinner | — |
| 21:00–25:00 | Free time | Friends, campus activities and recreation |
| 25:00–26:00 | Evening meal | — |
| 26:00–31:00 | Open personal time | Reading, socializing or rest |

**Approval:** Author approved Day 5 in sequence.

### Day 6 — Aiven · Rest day

| Local time | Activity | Details |
|---|---|---|
| 00:00–12:00 | Sleep | 12 hours; rest-day sleep-in |
| 12:00–13:00 | Breakfast | Relaxed, no academic obligations |
| 13:00–18:00 | Open campus exploration | Friends, university grounds, shops, Archives or city excursions |
| 18:00–19:00 | Lunch | Dining with friends or on campus |
| 19:00–23:00 | Recreation and social activities | Campus events, games, hobbies, friends |
| 23:00–25:00 | Personal downtime | Pleasure reading, relaxation or optional study |
| 25:00–26:00 | Dinner | — |
| 26:00–31:00 | Unstructured personal time | Free choice, rest or preparation for next cycle |

**Approval:** Author approved Day 6 in sequence.

## Semester I course ownership

The Semester I Helkir subjects are Genesis Field Theory I, Topology I and Anatomy I. The five-semester redistributed curriculum is still a working plan beyond this locked semester. No name has been chosen for the Helkir friend.

## Continuation and preservation protocol

- Semester II must be added *cumulatively* without deleting or shortening Semester I.
- Semesters III–V follow the same preservation requirement.
- A later combined three-character schedule ZIP must preserve the Helkir schedule, Kaira’s Cardsmith schedule and the Princess’s schedule independently, with shared availability cross-references.
- Do not invent any unscheduled named character, grades, class prerequisite, mandatory lab or fixed campus date.
- Repository publication is NOT claimed.
