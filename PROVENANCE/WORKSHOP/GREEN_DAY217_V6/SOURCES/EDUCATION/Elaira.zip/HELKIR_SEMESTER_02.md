# MK163 — Blackstone Keep · Helkir Primary Track · Semester II

**Status: AUTHOR-LOCKED — all six days approved in conversation (2026-11-12).**

This is the schedule of Kaira’s future unnamed **Helkir** friend, not Kaira’s Cardsmith timetable. Canonical protected spelling: **Helkir** (H-E-L-K-I-R); “healer” is a voice-to-text convenience and descriptive translation, never a replacement canonical term.

## Invariants

- Local day: **31 hours**. Six-day cycle: **Ailar, Aiden, Aiveth, Ailor, Aithen, Aiven**.
- Semester length: **96 local days**, or sixteen six-day academic cycles; this repeating timetable is independent of the university-wide recurring event calendar.
- Formal instructional days: Day 1 **Genesis Field Theory II, 11:00–13:00**; Day 3 **Differential Geometry I, 15:00–17:00**; Day 5 **Biology Lab I, 18:00–20:00**. Six required instructional hours per cycle; Day 5 is a **practical lab**, not a generic lecture.
- Days 2 and 4 have no compulsory lecture and allow optional study. Day 6 is rest and recreation without compulsory academic work.
- Study/research/tutoring blocks described as optional remain student-directed, not mandatory sessions. Social activities are opportunities, not pre-scripted events.
- Times are local 31-hour clock hours. No specific semester start date, campus event assignment, grade or experiment has been established.

## Approved six-day timetable

### Day 1 — Ailar · Genesis Field Theory II

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, prepare for day |
| 11:00–13:00 | Genesis Field Theory II | Required formal lecture · 2 hours |
| 13:00–15:00 | Guided field-theory exercises | Optional advanced Genesis practice |
| 15:00–16:00 | Lunch and rest | Meal break and socializing |
| 16:00–18:00 | Consultation / independent research | Optional faculty assistance or Grand Archives |
| 18:00–20:00 | Personal study | Flexible review and coursework preparation |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus events, recreation |
| 25:00–26:00 | Evening meal | Food and relaxation |
| 26:00–31:00 | Open personal time | Reading, socializing, hobbies or rest |

**Approval:** Author approved this day in sequence.

### Day 2 — Aiden · Independent study

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, prepare for day |
| 11:00–13:00 | Genesis Field Theory II review | Optional Day 1 lecture exercises |
| 13:00–15:00 | Independent research | Optional Grand Archives, assignments, personal investigation |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Differential Geometry preparation | Optional exercises before Day 3 lecture |
| 18:00–20:00 | Open campus time | Explore departments, meet friends, attend events |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus events, recreation |
| 25:00–26:00 | Evening meal | Food and relaxation |
| 26:00–31:00 | Open personal time | Reading, socializing, hobbies or rest |

**Approval:** Author approved this day in sequence.

### Day 3 — Aiveth · Differential Geometry I

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, prepare for day |
| 11:00–13:00 | Personal study | Optional geometry preparation or Genesis review |
| 13:00–15:00 | Independent exercises / early lunch | Flexible preparation, meal and travel before class |
| 15:00–17:00 | Differential Geometry I | Required formal lecture · Mathematics Department · 2 hours |
| 17:00–18:00 | Break and lunch | Rest, food, socializing |
| 18:00–20:00 | Geometry review / tutoring | Optional coursework or faculty consultation |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus events, recreation |
| 25:00–26:00 | Evening meal | Food and relaxation |
| 26:00–31:00 | Open personal time | Reading, socializing, hobbies or rest |

**Approval:** Author approved this day in sequence.

### Day 4 — Ailor · Independent study / laboratory preparation

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, prepare for day |
| 11:00–13:00 | Biology Lab I preparation | Optional laboratory reading and biological concepts |
| 13:00–15:00 | Independent practical study | Optional lab orientation, demonstrations or supervised exercises |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Study group / tutoring | Optional Genesis Field Theory II and Differential Geometry I review |
| 18:00–20:00 | Open campus time | Archives, friends, university events |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus events, recreation |
| 25:00–26:00 | Evening meal | Food and relaxation |
| 26:00–31:00 | Open personal time | Reading, socializing, hobbies or rest |

**Approval:** Author approved this day in sequence.

### Day 5 — Aithen · Biology Lab I

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, prepare for day |
| 11:00–13:00 | Personal study | Optional biology preparation and lab reading |
| 13:00–15:00 | Guided exercises | Optional biological study, procedures and concepts |
| 15:00–16:00 | Lunch | Meal and rest |
| 16:00–18:00 | Tutoring / Grand Archives | Optional research, consultation or preparation |
| 18:00–20:00 | Biology Lab I | Required supervised practical laboratory · Biological Sciences · 2 hours |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus events, recreation |
| 25:00–26:00 | Evening meal | Food and relaxation |
| 26:00–31:00 | Open personal time | Reading, socializing, hobbies or rest |

**Approval:** Author approved this day in sequence.

### Day 6 — Aiven · Rest and recreation

| Local time | Activity | Details |
|---|---|---|
| 00:00–12:00 | Sleep | 12 hours · rest-day sleep-in |
| 12:00–13:00 | Breakfast | Relaxed morning, no academic obligations |
| 13:00–18:00 | Open campus exploration | Friends, grounds, shopping, Archives or city excursions |
| 18:00–19:00 | Lunch | Dining with friends or on campus |
| 19:00–23:00 | Recreation and social activities | Campus events, games, hobbies or friends |
| 23:00–25:00 | Personal downtime | Reading for pleasure, relaxation or entirely optional study |
| 25:00–26:00 | Dinner | Evening meal |
| 26:00–31:00 | Unstructured personal time | Free choice, rest or preparation for next academic cycle |

**Approval:** Author approved this day in sequence.

## Semester II course ownership and continuity

Semester II contains Genesis Field Theory II, Differential Geometry I and Biology Lab I. Biology Lab I has a two-hour required practical session on Day 5. Its particular experiments and assessments are not established. The author explicitly requested varied lecture times across this semester and approved 11:00, 15:00 and 18:00 starts.

**Semester I is retained as a separate complete original file, byte-for-byte, within the cumulative ZIP.** Semesters III–V remain open. The Helkir friend’s personal name remains open. Kaira and the Princess have distinct future schedules, not included here.

## Preservation protocol

The next cumulative checkpoint must include complete unchanged Semester I and II files plus Semester III. Continue through Semester V without deleting, summarizing or overwriting approved schedules. This artifact is local, not a GitHub publication.
