# MK163 — Blackstone Keep · Helkir Primary Track · Semester 4

**Status: AUTHOR-LOCKED — all six days approved in conversation (2026-11-12).**

Schedule belongs to Kaira’s future unnamed **Helkir** friend, not Kaira. Protected spelling: **Helkir**.

## Invariants

- 31-hour local day; six weekdays Ailar, Aiden, Aiveth, Ailor, Aithen, Aiven.
- Semester length: 96 local days = sixteen six-day cycles.
- Required instructional sessions occur on Days 1, 3 and 5; Days 2 and 4 are flexible independent study; Day 6 is rest.
- All research, tutoring and practice blocks marked optional are student-directed, not compulsory.
- Meals at 25:00 are personal scheduled dining, not fixed cafeteria opening hours; cafeteria operates much of the day with closing hours unspecified.
- Campus event calendar runs independently; exact semester start dates are not set.
- Courses: Differential Geometry III; Chemistry II; Biology Lab II.

## Complete approved six-day timetable

### Day 1 — Ailar

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, and prepare |
| 11:00–13:00 | Independent mathematics study | Review Differential Geometry II and prepare for advanced material |
| 13:00–15:00 | Guided mathematical exercises | Optional advanced geometry problems and coursework |
| 15:00–17:00 | Differential Geometry III | Required lecture; 2 hours |
| 17:00–18:00 | Lunch and rest | Meal and socializing |
| 18:00–20:00 | Faculty consultation / Archives | Optional research, tutoring or lecture review |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus activities and recreation |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours flexible |
| 26:00–31:00 | Open personal time | Reading, hobbies, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 2 — Aiden

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, and prepare |
| 11:00–13:00 | Differential Geometry III review | Optional review and preparation |
| 13:00–15:00 | Independent research / practical study | Grand Archives, assignments or mathematical investigation |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Chemistry II preparation | Optional study group, exercises or tutoring |
| 18:00–20:00 | Open campus time | Friends, campus exploration or events |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus activities and recreation |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours flexible |
| 26:00–31:00 | Open personal time | Reading, hobbies, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 3 — Aiveth

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, and prepare |
| 11:00–13:00 | Chemistry II | Required lecture; 2 hours |
| 13:00–15:00 | Guided advanced chemistry exercises | Optional coursework and practice |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Faculty consultation / Archives | Optional research, tutoring or supervised demonstrations |
| 18:00–20:00 | Personal study | Optional advanced chemistry review |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus activities and recreation |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours flexible |
| 26:00–31:00 | Open personal time | Reading, hobbies, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 4 — Ailor

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, and prepare |
| 11:00–13:00 | Biology Lab II preparation | Review biological structures, laboratory procedures and prior coursework |
| 13:00–15:00 | Independent practical study | Optional biological demonstrations, lab exercises or supervised observation |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Study group / tutoring | Optional Differential Geometry III and Chemistry II review |
| 18:00–20:00 | Open campus time | Grand Archives, friends, campus exploration or university events |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus activities and recreation |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours flexible |
| 26:00–31:00 | Open personal time | Reading, hobbies, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 5 — Aithen

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, and prepare |
| 11:00–13:00 | Personal study | Biology Lab II preparation and review |
| 13:00–15:00 | Guided biological exercises | Optional practical preparation and coursework |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Tutoring / Grand Archives | Optional research, faculty consultation or lab preparation |
| 18:00–20:00 | Biology Lab II | Required supervised laboratory; 2 hours |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus activities and recreation |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours flexible |
| 26:00–31:00 | Open personal time | Reading, hobbies, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 6 — Aiven

| Local time | Activity | Details |
|---|---|---|
| 00:00–12:00 | Sleep | 12 hours; rest-day sleep-in |
| 12:00–13:00 | Breakfast | Relaxed start; no academic obligations |
| 13:00–18:00 | Open campus exploration | Friends, university grounds, shopping, Grand Archives or city excursions |
| 18:00–19:00 | Lunch | Dining with friends or on campus |
| 19:00–23:00 | Recreation and social activities | Campus events, games, hobbies or time with Kaira and the Princess |
| 23:00–25:00 | Personal downtime | Pleasure reading, relaxation or entirely optional study |
| 25:00–26:00 | Dinner | Personal dining time; cafeteria hours flexible |
| 26:00–31:00 | Unstructured personal time | Free choice, relaxation or preparation for next cycle |

**Approval:** Author approved this day in sequence.
