# MK163 — Blackstone Keep · Helkir Primary Track · Semester 5

**Status: AUTHOR-LOCKED — all six days approved in conversation (2026-11-12).**

Schedule belongs to Kaira’s future unnamed **Helkir** friend, not Kaira. Protected spelling: **Helkir**.

## Invariants

- 31-hour local day; six weekdays Ailar, Aiden, Aiveth, Ailor, Aithen, Aiven.
- Semester length: 96 local days = sixteen six-day cycles.
- Required instruction on Days 1, 3 and 5; Days 2 and 4 independent study; Day 6 rest.
- Study, research, consultation, guided practice and preparation are optional unless explicitly marked required.
- 25:00 dining is personal scheduling, not a cafeteria opening time. Dining hours are not fixed.
- Campus events have an independent recurring calendar; semester start date is unspecified.
- Courses: Quantum Field Theory I, Organic Chemistry I, Biology Lab III.

## Complete approved six-day timetable

### Day 1 — Ailar

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, and prepare for the day |
| 11:00–13:00 | Independent quantum theory study | Optional foundational preparation |
| 13:00–15:00 | Guided mathematical exercises | Optional quantum-theory exercises |
| 15:00–16:00 | Lunch | Meal and rest |
| 16:00–17:00 | Lecture preparation and travel | Prepare for Quantum Field Theory I |
| 17:00–19:00 | Quantum Field Theory I | Required lecture; 2 hours |
| 19:00–20:00 | Optional lecture review | Review concepts or relax |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus events and recreation |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours remain flexible |
| 26:00–31:00 | Open personal time | Reading, hobbies, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 2 — Aiden

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, and prepare for the day |
| 11:00–13:00 | Quantum Field Theory I review | Optional review of Day 1 concepts |
| 13:00–15:00 | Independent research | Grand Archives, assignments or personal investigation |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Organic Chemistry I preparation | Optional chemical structures, reactions and laboratory principles |
| 18:00–20:00 | Open campus time | Friends, departmental activities or university events |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus events and recreation |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours remain flexible |
| 26:00–31:00 | Open personal time | Reading, hobbies, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 3 — Aiveth

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, and prepare for the day |
| 11:00–13:00 | Personal study | Optional review of Chemistry II and organic chemistry preparation |
| 13:00–15:00 | Organic Chemistry I | Required lecture; 2 hours |
| 15:00–16:00 | Lunch | Meal and relaxation |
| 16:00–18:00 | Guided organic chemistry exercises | Optional chemical structures, reactions and coursework |
| 18:00–20:00 | Faculty consultation / Archives | Optional tutoring, research or lecture review |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus events and recreation |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours remain flexible |
| 26:00–31:00 | Open personal time | Reading, hobbies, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 4 — Ailor

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, and prepare for the day |
| 11:00–13:00 | Biology Lab III preparation | Optional review of previous laboratory work, biological structures and procedures |
| 13:00–15:00 | Independent practical study | Optional advanced biological exercises, demonstrations or supervised observation |
| 15:00–16:00 | Lunch | Meal and socializing |
| 16:00–18:00 | Study group / tutoring | Optional Quantum Field Theory I and Organic Chemistry I review |
| 18:00–20:00 | Open campus time | Grand Archives, friends, campus exploration or university events |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus events and recreation |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours remain flexible |
| 26:00–31:00 | Open personal time | Reading, hobbies, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 5 — Aithen

| Local time | Activity | Details |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Wake, eat, and prepare for the day |
| 11:00–13:00 | Personal study | Optional Biology Lab II review and advanced practical preparation |
| 13:00–15:00 | Guided biological exercises | Optional advanced laboratory preparation and coursework |
| 15:00–16:00 | Lunch | Meal and relaxation |
| 16:00–18:00 | Tutoring / Grand Archives | Optional faculty consultation, research or laboratory preparation |
| 18:00–20:00 | Biology Lab III | Required supervised laboratory; 2 hours |
| 20:00–21:00 | Dinner | Evening meal |
| 21:00–25:00 | Free time | Friends, campus events and recreation |
| 25:00–26:00 | Late meal | Personal dining time; cafeteria hours remain flexible |
| 26:00–31:00 | Open personal time | Reading, hobbies, socializing or rest |

**Approval:** Author approved this day in sequence.

### Day 6 — Aiven

| Local time | Activity | Details |
|---|---|---|
| 00:00–12:00 | Sleep | 12 hours; rest-day sleep-in |
| 12:00–13:00 | Breakfast | Relaxed start to the day |
| 13:00–18:00 | Open campus exploration | Friends, university grounds, shopping, Grand Archives or city excursions |
| 18:00–19:00 | Lunch | Dining with friends or on campus |
| 19:00–23:00 | Recreation and social activities | Campus events, games, hobbies or time with Kaira and the Princess |
| 23:00–25:00 | Personal downtime | Reading for pleasure, relaxation or entirely optional study |
| 25:00–26:00 | Dinner | Personal dining time; cafeteria hours remain flexible |
| 26:00–31:00 | Unstructured personal time | Free choice, relaxation or preparation for the next academic cycle |

**Approval:** Author approved this day in sequence.

## Weekly required instruction

| Day | Course | Time |
|---|---|---|
| 1 · Ailar | Quantum Field Theory I | 17:00–19:00 |
| 3 · Aiveth | Organic Chemistry I | 13:00–15:00 |
| 5 · Aithen | Biology Lab III | 18:00–20:00 |

## Continuity note

This semester is the fifth and final semester of the **primary** Helkir curriculum. Advanced and doctorate-level semesters are separate future development. The character’s personal name remains open.
