# Blackstone Keep — Princess, Semester IV: Resolution and Stability

**Status: AUTHOR-APPROVED / LOCKED — all six daily patterns.**

Courses: Differential Geometry I; Transduction Theory II; Native Genesis Control III.

The Princess is an awakened aen-control prodigy, specializing in native Genesis transduction. Canonical lifecycle: Conceive → Shape → Hold → Resolve → Manifest → Release.

The alchemist introduces Kaira to the Princess early; their friendship and their unnamed Helkir friend are central to study alignment. Same-semester identical courses share exact lecture sections.

## Day 1 — Ailar: Differential Geometry I

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | Shared mathematics study | Princess and Kaira Geometry I prep; Helkir Geometry III review |
| 13:00–15:00 | Shared geometry exercises | Different levels, same study space |
| 15:00–17:00 | REQUIRED — Differential Geometry I | Same section as Kaira; Helkir Differential Geometry III separately |
| 17:00–18:00 | Lunch together | All three |
| 18:00–20:00 | Shared mathematics review | Princess/Kaira Geometry I; Helkir Geometry III |
| 20:00–21:00 | Dinner together | All three girls available |
| 21:00–25:00 | Free time | Campus events, friendship, recreation |
| 25:00–26:00 | Late meal | Personal dining time, not fixed cafeteria hours |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation |

**Workload:** 2h compulsory, 6h optional study/practice, 9h open personal time.

**Alignment:** Princess and Kaira share Differential Geometry I 15:00–17:00; Helkir separate Differential Geometry III at same time.


## Day 2 — Aiden: Independent study

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | Shared mathematics study | Princess/Kaira Geometry I; Helkir Geometry III |
| 13:00–15:00 | Shared transduction research | Princess/Kaira Transduction II; Helkir mathematical research |
| 15:00–16:00 | Lunch together | All three |
| 16:00–18:00 | Native Genesis Control III preparation | Princess aen stability; Kaira Transduction II; Helkir Chemistry II |
| 18:00–20:00 | Open campus time | Friends, Archives |
| 20:00–21:00 | Dinner together | All three girls available |
| 21:00–25:00 | Free time | Campus events, friendship, recreation |
| 25:00–26:00 | Late meal | Personal dining time, not fixed cafeteria hours |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation |

**Workload:** 0h compulsory, 6h optional study/practice, 11h open personal time.

**Alignment:** Six study hours aligned with Kaira and Helkir.


## Day 3 — Aiveth: Transduction Theory II

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | Transduction Theory II preparation | Princess/Kaira; Helkir Chemistry II lecture |
| 13:00–15:00 | Shared transduction research | Princess/Kaira advanced resolution; Helkir chemistry review |
| 15:00–16:00 | Lunch together | All three |
| 16:00–18:00 | REQUIRED — Transduction Theory II | Same section as Kaira |
| 18:00–20:00 | Shared study / Grand Archives | Native and engineered transduction; Helkir chemistry |
| 20:00–21:00 | Dinner together | All three girls available |
| 21:00–25:00 | Free time | Campus events, friendship, recreation |
| 25:00–26:00 | Late meal | Personal dining time, not fixed cafeteria hours |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation |

**Workload:** 2h compulsory, 6h optional study/practice, 9h open personal time.

**Alignment:** Princess and Kaira share Transduction Theory II 16:00–18:00; Helkir Chemistry II 11:00–13:00.


## Day 4 — Ailor: Independent study

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | Shared mathematics study | Princess/Kaira Geometry I; Helkir Geometry III |
| 13:00–15:00 | Shared transduction research | Princess Transduction II; Kaira Binding Circle prep; Helkir Biology Lab II prep |
| 15:00–16:00 | Lunch together | All three |
| 16:00–18:00 | Native Genesis Control III preparation | Princess advanced aen; Kaira Geometry/Transduction; Helkir Geometry/Chemistry |
| 18:00–20:00 | Open campus time | Friends, Archives |
| 20:00–21:00 | Dinner together | All three girls available |
| 21:00–25:00 | Free time | Campus events, friendship, recreation |
| 25:00–26:00 | Late meal | Personal dining time, not fixed cafeteria hours |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation |

**Workload:** 0h compulsory, 6h optional study/practice, 11h open personal time.

**Alignment:** Six study hours aligned; different course focus 13:00–18:00.


## Day 5 — Aithen: Native Genesis Control III

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | Shared Genesis research | Princess native control; Kaira Binding Circle prep; Helkir Biology Lab II prep |
| 13:00–15:00 | Independent native aen study | Princess practice; Kaira Binding Circle Fundamentals lecture |
| 15:00–16:00 | Lunch with Kaira | Helkir friend available |
| 16:00–18:00 | REQUIRED — Native Genesis Control III | Princess-only advanced native control |
| 18:00–20:00 | Optional control review / Grand Archives | Helkir Biology Lab II lecture; Kaira optional practice |
| 20:00–21:00 | Dinner together | All three girls available |
| 21:00–25:00 | Free time | Campus events, friendship, recreation |
| 25:00–26:00 | Late meal | Personal dining time, not fixed cafeteria hours |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation |

**Workload:** 2h compulsory, 6h optional study/practice, 9h open personal time.

**Alignment:** Princess class 16:00–18:00; Kaira Binding Circle Fundamentals 13:00–15:00; Helkir Biology Lab II 18:00–20:00.


## Day 6 — Aiven: Protected rest and recreation

| Time | Activity | Notes |
|---|---|---|
| 00:00–12:00 | Sleep | 12-hour rest-day sleep-in |
| 12:00–13:00 | Breakfast | Relaxed start |
| 13:00–18:00 | Open campus exploration | Blackstone, Grand Archives, shopping, excursions, friends |
| 18:00–19:00 | Lunch together | All three girls |
| 19:00–23:00 | Recreation and social activities | Events, games, friends |
| 23:00–25:00 | Personal downtime | Reading and relaxation |
| 25:00–26:00 | Dinner | Personal dining time, not cafeteria opening |
| 26:00–31:00 | Unstructured personal time | Friends, hobbies, rest |

**Workload:** 0h compulsory, 0h optional study/practice, 16h open personal time.

**Alignment:** Exact rest-day alignment with Kaira and Helkir friend.


## Curriculum and narrative continuity

Differential Geometry I and Transduction Theory II share exact sections with Kaira. Native Genesis Control III is the Princess-only final dedicated control course before Semester V Native Genesis Laboratory I.

All six day patterns recur throughout the 96-day semester. The 31-hour clock is retained. Aiven is a protected rest day; personal late meals do not prescribe cafeteria opening hours.
