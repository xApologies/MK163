# Blackstone Keep — Princess, Semester I: Genesis Foundations

**Status: AUTHOR-APPROVED / LOCKED — all six daily patterns.**

Three courses: Genesis Field Theory I, Topology I, Native Genesis Control I.

The Princess is an awakened aen-control prodigy. Native control practice emphasizes discipline, precision, stability and safe release, not discovering awakening. Six-stage AERA lifecycle: Conceive → Shape → Hold → Resolve → Manifest → Release.

The alchemist introduces Kaira to the Princess early; Kaira, Princess and unnamed Helkir friend are already friends. Same-course same-semester lectures use the same section; different subjects are separate.

## Day 1 — Ailar: Genesis Field Theory I

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | REQUIRED — Genesis Field Theory I | Shared lecture section with Kaira and Helkir friend |
| 13:00–15:00 | Shared independent study | All three review Genesis Field Theory I |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Optional native Genesis practice | Aen awareness, initiation and restraint; Kaira and Helkir friend work on their own disciplines |
| 18:00–20:00 | Open campus time | Friends, exploration, informal transduction discussion |
| 20:00–21:00 | Dinner together | Shared meal |
| 21:00–25:00 | Free time | Recreation and friendship |
| 25:00–26:00 | Late meal | Personal meal, not a fixed cafeteria opening |
| 26:00–31:00 | Personal time | Reading, hobbies, relaxation |

**Workload:** 2h compulsory instruction; 4h optional study/practice; 11h open personal time.

**Alignment:** Genesis Field Theory I 11:00–13:00 is the same lecture as Kaira and the Helkir friend. 13:00–15:00 shared review; 15:00 lunch; 20:00 dinner.

## Day 2 — Aiden: Shared independent study

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast | Morning routine |
| 11:00–13:00 | Shared Genesis Field study | All three review Genesis Field Theory I |
| 13:00–15:00 | Shared mathematics study | All three prepare for Topology I |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Optional Native Genesis Control I practice | Aen regulation, Shape/Hold emphasis; full lifecycle remains applicable |
| 18:00–20:00 | Open campus time | Friends and Grand Archives |
| 20:00–21:00 | Dinner together | Shared meal |
| 21:00–25:00 | Free time | Recreation and friendship |
| 25:00–26:00 | Late meal | Personal meal |
| 26:00–31:00 | Personal time | Relaxation |

**Workload:** 0h compulsory instruction; 6h optional study/practice; 11h open personal time.

**Alignment:** 11:00–15:00 shared Genesis and Topology study; 16:00–18:00 separate-discipline study in compatible period.

## Day 3 — Aiveth: Topology I

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | REQUIRED — Topology I | Shared lecture section with Kaira and Helkir friend |
| 13:00–15:00 | Shared topology study | All three review topology and geometric relationships |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Optional native Genesis practice | Connect topology to aen shaping and stability |
| 18:00–20:00 | Shared study / Grand Archives | Genesis and Topology review with friends |
| 20:00–21:00 | Dinner together | Shared meal |
| 21:00–25:00 | Free time | Recreation and friendship |
| 25:00–26:00 | Late meal | Personal meal |
| 26:00–31:00 | Personal time | Relaxation |

**Workload:** 2h compulsory instruction; 6h optional study/practice; 9h open personal time.

**Alignment:** Topology I 11:00–13:00 same lecture section as both friends. Shared 13:00–15:00 and 18:00–20:00 study.

## Day 4 — Ailor: Shared independent study

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast | Morning routine |
| 11:00–13:00 | Shared Genesis Field study | All three review Genesis Field Theory I |
| 13:00–15:00 | Shared mathematics study | All three study Topology I |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Optional native Genesis Control I preparation | Aen awareness, Shape/Hold stability, controlled release |
| 18:00–20:00 | Open campus time | Archives, exploration, friends |
| 20:00–21:00 | Dinner together | Shared meal |
| 21:00–25:00 | Free time | Recreation and friendship |
| 25:00–26:00 | Late meal | Personal meal |
| 26:00–31:00 | Personal time | Relaxation |

**Workload:** 0h compulsory instruction; 6h optional study/practice; 11h open personal time.

**Alignment:** Shared 11:00–15:00 Genesis and topology study; 16:00–18:00 separate subject preparation.

## Day 5 — Aithen: Native Genesis Control I

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | Shared Genesis Field study | All three review Genesis Field Theory I |
| 13:00–15:00 | Shared mathematics study | All three study Topology I |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Optional native Genesis control preparation | Aen regulation, configuration, lifecycle practice |
| 18:00–20:00 | REQUIRED — Native Genesis Control I | Princess practical class; simultaneously Kaira Cardsmithing Fundamentals I and Helkir friend Anatomy I in separate sections |
| 20:00–21:00 | Dinner together | All three reunite after classes |
| 21:00–25:00 | Free time | Recreation and friendship |
| 25:00–26:00 | Late meal | Personal meal |
| 26:00–31:00 | Personal time | Relaxation |

**Workload:** 2h compulsory instruction; 6h optional study/practice; 9h open personal time.

**Alignment:** Three different specialist classes simultaneously 18:00–20:00; shared study 11:00–15:00 and dinner 20:00–21:00.

## Day 6 — Aiven: Rest and recreation

| Time | Activity | Notes |
|---|---|---|
| 00:00–12:00 | Sleep | 12-hour rest-day sleep-in |
| 12:00–13:00 | Breakfast | Relaxed start |
| 13:00–18:00 | Open campus exploration | Blackstone, Grand Archives, shopping, excursions, friends |
| 18:00–19:00 | Lunch together | Shared meal |
| 19:00–23:00 | Recreation and social activities | Campus events, games, hobbies, friends |
| 23:00–25:00 | Personal downtime | Reading for pleasure, relaxation |
| 25:00–26:00 | Dinner | Personal meal, not fixed cafeteria hours |
| 26:00–31:00 | Unstructured personal time | Friendship, hobbies, rest |

**Workload:** 0h compulsory instruction; 0h optional study/practice; 16h open personal time.

**Alignment:** Exact same protected rest-day schedule as Kaira and Helkir friend; no compulsory classes or study.

## Integrity and continuity notes

- All six daily schedules explicitly approved through the user’s Day 6 / Semester I completion confirmation.
- The 31-hour clock uses 25:00, 26:00 and 31:00 intentionally.
- Meal slots are personal choices, not cafeteria operating hours.
- The Princess’s personal name and the Helkir friend’s personal name remain open.
- The course map covers five semesters; only Semester I daily schedules are included and locked in this checkpoint.
- Do not introduce binding circles, cardsmithing, or healing as Princess specializations.
