# Blackstone Keep — Princess, Semester II: Field Control and Material Interaction

**Status: AUTHOR-APPROVED / LOCKED — all six daily patterns.**

Courses: Genesis Field Theory II; Chemistry I; Native Genesis Control II.

The Princess is an awakened aen-control prodigy. She trains direct native Genesis transduction rather than cardsmithing, healing, or binding circles. Canonical lifecycle: Conceive → Shape → Hold → Resolve → Manifest → Release.

**Continuity:** The alchemist introduces Kaira to the Princess early. Kaira and the unnamed Helkir friend are close friends. Shared same-semester courses have the same lecture section; different disciplines are studied in parallel.

## Day 1 — Ailar: Genesis Field Theory II

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | REQUIRED — Genesis Field Theory II | Same lecture section as Kaira and Helkir friend |
| 13:00–15:00 | Shared Genesis Field study | All three review field configuration, resolution and persistence |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Optional Native Genesis Control II practice | Precision, sustained configuration and deliberate release |
| 18:00–20:00 | Shared study / Grand Archives | Three friends study own subjects alongside each other |
| 20:00–21:00 | Dinner together | All three friends available |
| 21:00–25:00 | Free time | Campus recreation, friends |
| 25:00–26:00 | Late meal | Personal meal, not campus cafeteria opening |
| 26:00–31:00 | Personal time | Reading, relaxation, hobbies |

**Workload:** 2h compulsory, 6h optional study/practice, 9h open personal time.

**Alignment:** Genesis Field Theory II 11:00–13:00 shared with both friends.

## Day 2 — Aiden: Independent study

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | Shared Genesis Field study | All three review Genesis Field Theory II |
| 13:00–15:00 | Shared Chemistry I study | Princess and Kaira chemistry; Helkir friend Differential Geometry I |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Optional Native Genesis Control II practice | Aen precision, Shape/Hold stability and controlled Release; friends study nearby |
| 18:00–20:00 | Open campus time | Archives, exploration and friends |
| 20:00–21:00 | Dinner together | All three friends available |
| 21:00–25:00 | Free time | Campus recreation, friends |
| 25:00–26:00 | Late meal | Personal meal, not campus cafeteria opening |
| 26:00–31:00 | Personal time | Reading, relaxation, hobbies |

**Workload:** 0h compulsory, 6h optional study/practice, 11h open personal time.

**Alignment:** All three study 11:00–15:00; 16:00–18:00 separate-subject practice.

## Day 3 — Aiveth: Chemistry I

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | REQUIRED — Chemistry I | Same lecture section as Kaira; Helkir friend independent geometry study |
| 13:00–15:00 | Shared Chemistry I review | Princess and Kaira review; Helkir friend geometry study alongside |
| 15:00–16:00 | Lunch with Kaira | Helkir friend attends Differential Geometry I 15:00–17:00 |
| 16:00–18:00 | Optional Native Genesis Control II practice | Aen precision and controlled material interaction; Helkir friend in geometry class until 17:00 |
| 18:00–20:00 | Shared study / Grand Archives | All three available for individual coursework |
| 20:00–21:00 | Dinner together | All three friends available |
| 21:00–25:00 | Free time | Campus recreation, friends |
| 25:00–26:00 | Late meal | Personal meal, not campus cafeteria opening |
| 26:00–31:00 | Personal time | Reading, relaxation, hobbies |

**Workload:** 2h compulsory, 6h optional study/practice, 9h open personal time.

**Alignment:** Chemistry I 11:00–13:00 shared with Kaira. Helkir Differential Geometry I 15:00–17:00; no overlap in compulsory classes.

## Day 4 — Ailor: Independent study

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | Shared Genesis Field study | All three review Genesis Field Theory II |
| 13:00–15:00 | Shared independent research | Princess and Kaira Chemistry I; Helkir friend Differential Geometry I |
| 15:00–16:00 | Lunch together | Shared meal |
| 16:00–18:00 | Optional Native Genesis Control II preparation | Precision, sustained configurations, controlled release; friends study nearby |
| 18:00–20:00 | Open campus time | Archives, exploration and friends |
| 20:00–21:00 | Dinner together | All three friends available |
| 21:00–25:00 | Free time | Campus recreation, friends |
| 25:00–26:00 | Late meal | Personal meal, not campus cafeteria opening |
| 26:00–31:00 | Personal time | Reading, relaxation, hobbies |

**Workload:** 0h compulsory, 6h optional study/practice, 11h open personal time.

**Alignment:** Shared study 11:00–15:00; separate preparation 16:00–18:00.

## Day 5 — Aithen: Native Genesis Control II

| Time | Activity | Notes |
|---|---|---|
| 00:00–10:00 | Sleep | 10 hours |
| 10:00–11:00 | Breakfast and preparation | Morning routine |
| 11:00–13:00 | Shared Genesis Field study | Princess reviews Genesis Field II; friends available for independent study |
| 13:00–15:00 | Native Genesis Control II preparation | Optional precision, regulation and configuration exercises |
| 15:00–17:00 | REQUIRED — Native Genesis Control II | Afternoon practical class; no shared course with Kaira |
| 17:00–18:00 | Lunch and relaxation | After class; Helkir friend prepares for Biology Lab I |
| 18:00–20:00 | Optional study / Grand Archives | Princess reviews native control; Helkir friend Biology Lab I 18:00–20:00 |
| 20:00–21:00 | Dinner together | All three friends available |
| 21:00–25:00 | Free time | Campus recreation, friends |
| 25:00–26:00 | Late meal | Personal meal, not campus cafeteria opening |
| 26:00–31:00 | Personal time | Reading, relaxation, hobbies |

**Workload:** 2h compulsory, 6h optional study/practice, 9h open personal time.

**Alignment:** Native Genesis Control II 15:00–17:00 is Princess-only. Helkir Biology Lab I 18:00–20:00. All available for 20:00 dinner.

## Day 6 — Aiven: Protected rest and recreation

| Time | Activity | Notes |
|---|---|---|
| 00:00–12:00 | Sleep | 12 hours |
| 12:00–13:00 | Breakfast | Relaxed morning |
| 13:00–18:00 | Open campus exploration | Blackstone grounds, Grand Archives, excursions, friends |
| 18:00–19:00 | Lunch together | Shared meal |
| 19:00–23:00 | Recreation and social activities | Games, events, hobbies and friends |
| 23:00–25:00 | Personal downtime | Relaxation, reading for pleasure |
| 25:00–26:00 | Dinner | Personal dining time, not fixed cafeteria hours |
| 26:00–31:00 | Unstructured personal time | Friends, hobbies, rest |

**Workload:** 0h compulsory instruction, 0h required study, 16h open personal time.

**Alignment:** Exact same rest-day pattern as Kaira and the Helkir friend.

## Semester II academic and scheduling audit

- Three courses; six recurring day patterns; 31-hour day; 96-day semester.
- Required lectures: Ailar Genesis Field Theory II 11:00–13:00; Aiveth Chemistry I 11:00–13:00; Aithen Native Genesis Control II 15:00–17:00.
- Aiden and Ailor are independent-study days; Aiven is protected rest.
- Chemistry I is shared with Kaira; Genesis Field Theory II is shared with both friends.
- Native Genesis Control II emphasizes aen precision, stable configurations, resolution discipline and controlled release while preserving all six canonical lifecycle operations.
- Day 5 afternoon time 15:00–17:00 was explicitly selected by the author; Day 6 was subsequently approved.
