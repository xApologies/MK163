# Blackstone Keep — Princess: Five-Semester Primary Course Map

Status: **Author-approved**. Character's personal name remains OPEN.
Specialization: **Native Genesis Transduction** through awakened aen. The Princess is a transduction prodigy. She is introduced to Kaira early through the alchemist; they become good friends. She can help Kaira learn native aen control. She does not specialize in healing, cardsmithing, or binding circles.

The canonical six-stage transduction lifecycle is **Conceive → Shape → Hold → Resolve → Manifest → Release**. AERA L1 is authoritative for its detailed mechanics; this curriculum does not replace that reference.

| Semester | Focus | Course 1 | Course 2 | Course 3 |
|---|---|---|---|---|
| I | Genesis Foundations | Genesis Field Theory I | Topology I | Native Genesis Control I |
| II | Field Control and Material Interaction | Genesis Field Theory II | Chemistry I | Native Genesis Control II |
| III | Transduction Structure | Genesis Field Theory III | Quantum Field Theory I | Transduction Theory I |
| IV | Resolution and Stability | Differential Geometry I | Transduction Theory II | Native Genesis Control III |
| V | Applied Native Transduction | Applied Transduction Systems | Quantum Field Theory II | Native Genesis Laboratory I |

Shared courses must use the **same section and time** when the same course occurs in the same semester. Other classes may be separate while optional study, meals and rest remain synchronized.

World calendar: 31-hour day, six-day week Ailar / Aiden / Aiveth / Ailor / Aithen / Aiven, 96-day semester. The six daily patterns recur weekly.
